package jooqJPA.jooqJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JooqJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JooqJpaApplication.class, args);
	}

}
